# GPS Navigation System (Data Structures)

## What this project does
A visual educational website built with Python and Streamlit. It demonstrates:
1. Floyd–Warshall: shortest distances between every pair of locations.
2. Prim's MST: minimum-total-weight set of roads connecting all locations.
3. A*: a route between a selected start and destination.

The map uses sample locations and distances. It is not live GPS.

## Run on a laptop or desktop
1. Install Python 3.10 or newer from https://www.python.org/downloads/
2. Extract this project ZIP to a folder.
3. Open Terminal / Command Prompt in that folder.
4. Install packages:
   `python -m pip install -r requirements.txt`
5. Start the website:
   `python -m streamlit run app.py`
6. Your browser should open. If it does not, copy the local URL printed in the terminal (usually http://localhost:8501) into your browser.

## Run on a phone
You can use an online Python environment that supports Streamlit, or run it on a computer and open its shared web link on your phone. A plain Android browser cannot directly run the Python Streamlit app by opening app.py.

## Demo steps
1. Select College as the start and Airport as the destination.
2. Select A* Route Finder and click Run algorithm.
3. Select Floyd–Warshall All-Pairs Distances and click Run algorithm.
4. Select Prim's Minimum Spanning Tree and click Run algorithm.
5. Take screenshots of the map and outputs for your PPT.

## Data Structures concepts
- Graph vertices and weighted edges
- Distance matrix
- Priority queue
- Visited set and MST edge list
